package com.fischmacro

import kotlin.math.abs

class Blob(val cx: Float, val cy: Float, val area: Int, val bw: Int, val bh: Int)

object Detect {
    fun close(p: Int, c: Int, tol: Int): Boolean =
        abs(((p shr 16) and 255) - ((c shr 16) and 255)) <= tol &&
        abs(((p shr 8) and 255) - ((c shr 8) and 255)) <= tol &&
        abs((p and 255) - (c and 255)) <= tol

    fun count(reg: Screen.Region, color: Int, tol: Int): Int {
        var n = 0
        for (p in reg.px) if (close(p, color, tol)) n++
        return n
    }

    private val DX = intArrayOf(1, -1, 0, 0)
    private val DY = intArrayOf(0, 0, 1, -1)

    fun blobs(reg: Screen.Region, color: Int, tol: Int, cell: Int = 5): List<Blob> {
        val gw = (reg.w + cell - 1) / cell
        val gh = (reg.h + cell - 1) / cell
        val cnt = IntArray(gw * gh)
        for (y in 0 until reg.h) {
            val row = y * reg.w; val gy = (y / cell) * gw
            for (x in 0 until reg.w) if (close(reg.px[row + x], color, tol)) cnt[gy + x / cell]++
        }
        val thr = cell * cell / 4
        val seen = BooleanArray(gw * gh)
        val stack = IntArray(gw * gh)
        val out = ArrayList<Blob>()
        for (start in cnt.indices) {
            if (seen[start] || cnt[start] < thr) continue
            var sp = 0; stack[sp++] = start; seen[start] = true
            var area = 0; var sx = 0f; var sy = 0f
            var minX = gw; var maxX = -1; var minY = gh; var maxY = -1
            while (sp > 0) {
                val c = stack[--sp]; val cx = c % gw; val cy = c / gw; val n = cnt[c]
                area += n; sx += (cx + 0.5f) * cell * n; sy += (cy + 0.5f) * cell * n
                if (cx < minX) minX = cx; if (cx > maxX) maxX = cx
                if (cy < minY) minY = cy; if (cy > maxY) maxY = cy
                for (d in 0..3) {
                    val nx = cx + DX[d]; val ny = cy + DY[d]
                    if (nx in 0 until gw && ny in 0 until gh) {
                        val ni = ny * gw + nx
                        if (!seen[ni] && cnt[ni] >= thr) { seen[ni] = true; stack[sp++] = ni }
                    }
                }
            }
            out += Blob(reg.x0 + sx / area, reg.y0 + sy / area, area, (maxX - minX + 1) * cell, (maxY - minY + 1) * cell)
        }
        return out
    }

    /** Finds the biggest roughly-square blob of a color inside rect prefix ("s" or "t"). */
    fun pickBlob(prefix: String, colorKey: String): Blob? {
        val reg = Screen.grab(Config.rect(prefix)) ?: return null
        val total = Screen.w.toFloat() * Screen.h
        val minA = Config.f("$prefix.minArea") / 100f * total
        val maxA = Config.f("$prefix.maxArea") / 100f * total
        return blobs(reg, Config.col(colorKey), Config.f("$prefix.tol").toInt())
            .filter { it.area >= minA && it.area <= maxA && it.bw.toFloat() / it.bh in 0.4f..2.5f }
            .maxByOrNull { it.area }
    }
}