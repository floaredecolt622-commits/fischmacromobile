package com.fischmacro

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private lateinit var info: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        Config.init(this)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 24, 32, 24) }
        info = TextView(this).apply { textSize = 14f }
        root.addView(TextView(this).apply {
            text = "Fisch Macro\n1) Grant overlay  2) Enable accessibility  3) Start, then open Fisch in landscape.\n" +
                "In-game: use Debug to align boxes, Color/Pick to sample colors, Start to run."
        })
        root.addView(info)
        fun button(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }
        root.addView(button("1. Grant overlay permission") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(button("2. Enable accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(button("3. Start (screen capture) & open Roblox") {
            if (!Settings.canDrawOverlays(this)) { toast("Grant overlay permission first"); return@button }
            if (MacroAccessibility.inst == null) { toast("Enable accessibility service first"); return@button }
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), 100)
        })
        root.addView(button("Stop everything") { stopService(Intent(this, CaptureService::class.java)) })
        root.addView(button("Reset all settings") { Config.reset(); recreate() })

        val headers = mapOf("g" to "General", "s" to "Shake button finder", "std" to "Standard reel",
            "rh" to "Rhythm lanes", "t" to "Target tap")
        var lastGroup = ""
        for (k in Config.defaults.keys) {
            val g = k.substringBefore('.')
            if (g != lastGroup) {
                lastGroup = g
                root.addView(TextView(this).apply { text = "- ${headers[g]} -"; textSize = 16f; setPadding(0, 24, 0, 4) })
            }
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply { text = k }, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(EditText(this).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                setText(Config.f(k).toString())
                addTextChangedListener(object : TextWatcher {
                    override fun afterTextChanged(s: Editable?) { s.toString().toFloatOrNull()?.let { Config.setF(k, it) } }
                    override fun beforeTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                    override fun onTextChanged(a: CharSequence?, b: Int, c: Int, d: Int) {}
                })
            }, LinearLayout.LayoutParams(300, -2))
            root.addView(row)
        }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        info.text = "Overlay: ${Settings.canDrawOverlays(this)}   Accessibility: ${MacroAccessibility.inst != null}   " +
            "Capture running: ${CaptureService.running}"
    }

    @Deprecated("fine for this")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 100 && res == RESULT_OK && data != null) {
            startForegroundService(Intent(this, CaptureService::class.java)
                .putExtra(CaptureService.EXTRA_CODE, res).putExtra(CaptureService.EXTRA_DATA, data))
            packageManager.getLaunchIntentForPackage("com.roblox.client")?.let { startActivity(it) }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}