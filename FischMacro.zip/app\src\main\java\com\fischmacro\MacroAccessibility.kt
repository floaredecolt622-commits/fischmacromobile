package com.fischmacro

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class MacroAccessibility : AccessibilityService() {
    companion object {
        @Volatile var inst: MacroAccessibility? = null
        fun setHold(want: Boolean, x: Float, y: Float) { val s = inst ?: return; s.h.post { s.hold(want, x, y) } }
        fun tap(pts: List<Pair<Float, Float>>, ms: Long = 35) { val s = inst ?: return; s.h.post { s.doTap(pts, ms) } }
    }

    internal val h = Handler(Looper.getMainLooper())
    private var wantHold = false
    private var stroke: GestureDescription.StrokeDescription? = null
    private var inFlight = false
    private var hx = 0f
    private var hy = 0f
    private val SEG = 40L

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onDestroy() { inst = null; super.onDestroy() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun doTap(pts: List<Pair<Float, Float>>, ms: Long) {
        val b = GestureDescription.Builder()
        for ((x, y) in pts.take(9)) {
            b.addStroke(GestureDescription.StrokeDescription(Path().apply { moveTo(x, y) }, 0, ms))
        }
        dispatchGesture(b.build(), null, null)
    }

    private fun hold(want: Boolean, x: Float, y: Float) {
        hx = x; hy = y; wantHold = want
        pump()
    }

    private fun pump() {
        if (inFlight) return
        val path = Path().apply { moveTo(hx, hy) }
        val prev = stroke
        val s: GestureDescription.StrokeDescription
        if (wantHold) {
            s = prev?.continueStroke(path, 0, SEG, true)
                ?: GestureDescription.StrokeDescription(path, 0, SEG, true)
            stroke = s
        } else {
            val cur = prev ?: return
            s = cur.continueStroke(path, 0, 1, false)
            stroke = null
        }
        inFlight = true
        val ok = dispatchGesture(GestureDescription.Builder().addStroke(s).build(),
            object : GestureResultCallback() {
                override fun onCompleted(g: GestureDescription?) { inFlight = false; h.post { pump() } }
                override fun onCancelled(g: GestureDescription?) {
                    inFlight = false; stroke = null
                    h.post { if (wantHold) pump() }
                }
            }, h)
        if (!ok) { inFlight = false; stroke = null }
    }
}