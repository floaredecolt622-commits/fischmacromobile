package com.fischmacro

import android.content.Context
import android.content.SharedPreferences

object Config {
    private lateinit var p: SharedPreferences
    fun init(c: Context) { if (!::p.isInitialized) p = c.applicationContext.getSharedPreferences("cfg", 0) }

    // Positions/regions are fractions (0..1) of the screen. Landscape assumed.
    val defaults = linkedMapOf(
        // general
        "g.castX" to 0.55f, "g.castY" to 0.45f,
        "g.castHoldMs" to 900f,
        "g.settleMs" to 1200f,
        "g.biteTimeoutMs" to 45000f,
        "g.endGraceMs" to 1200f,
        "g.postCatchMs" to 2000f,
        "g.holdX" to 0.6f, "g.holdY" to 0.5f,
        // shake button finder
        "s.l" to 0.10f, "s.t" to 0.10f, "s.r" to 0.90f, "s.b" to 0.85f,
        "s.tol" to 30f, "s.minArea" to 0.02f, "s.maxArea" to 1.5f, "s.delayMs" to 70f,
        // standard reel
        "std.l" to 0.25f, "std.t" to 0.80f, "std.r" to 0.75f, "std.b" to 0.90f,
        "std.tol" to 25f, "std.minCount" to 150f,
        "std.kd" to 0.12f, "std.db" to 0.08f, "std.invert" to 0f,
        // rhythm lanes
        "rh.l" to 0.25f, "rh.t" to 0.70f, "rh.r" to 0.75f, "rh.b" to 0.85f,
        "rh.lanes" to 4f, "rh.tol" to 40f, "rh.minPx" to 25f, "rh.uiMin" to 100f, "rh.cooldownMs" to 80f,
        // target tap
        "t.l" to 0.10f, "t.t" to 0.10f, "t.r" to 0.90f, "t.b" to 0.90f,
        "t.tol" to 30f, "t.minArea" to 0.02f, "t.maxArea" to 3f, "t.cooldownMs" to 70f
    )
    // Placeholders. Use the eyedropper in the overlay to set real values.
    val colorDefaults = mapOf(
        "bar" to 0xFFFFFFFF.toInt(), "fish" to 0xFF5A6470.toInt(), "shake" to 0xFFFFFFFF.toInt(),
        "note" to 0xFFFFFFFF.toInt(), "rhui" to 0xFFFFD700.toInt(), "target" to 0xFFFF4040.toInt()
    )

    fun f(k: String): Float = p.getFloat(k, defaults.getValue(k))
    fun setF(k: String, v: Float) = p.edit().putFloat(k, v).apply()
    fun col(k: String): Int = p.getInt("col.$k", colorDefaults.getValue(k))
    fun setCol(k: String, v: Int) = p.edit().putInt("col.$k", v).apply()
    fun rect(prefix: String) = floatArrayOf(f("$prefix.l"), f("$prefix.t"), f("$prefix.r"), f("$prefix.b"))
    fun reset() = p.edit().clear().apply()
    var mode: Int
        get() = p.getInt("mode", 0)
        set(v) = p.edit().putInt("mode", v).apply()
}