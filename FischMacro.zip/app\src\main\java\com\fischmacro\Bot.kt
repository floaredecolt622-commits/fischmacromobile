package com.fischmacro

import android.os.SystemClock
import kotlinx.coroutines.*

class Bot(private val scope: CoroutineScope, private val onStatus: (String) -> Unit) {
    private var job: Job? = null
    val running get() = job?.isActive == true

    fun start() {
        if (running) return
        job = scope.launch(Dispatchers.Default) {
            try { loop() } finally {
                MacroAccessibility.setHold(false, 0f, 0f)
                onStatus("Stopped")
            }
        }
    }
    fun stop() { job?.cancel() }

    private fun ms(k: String) = Config.f(k).toLong()

    private suspend fun loop() = coroutineScope {
        val mode = Modes.create(Config.mode)
        var caught = 0
        while (isActive) {
            if (Screen.frameId == 0L) { onStatus("Waiting for screen frames..."); delay(500); continue }
            val cx = Config.f("g.castX") * Screen.realW
            val cy = Config.f("g.castY") * Screen.realH

            onStatus("Casting")
            MacroAccessibility.setHold(true, cx, cy)
            delay(ms("g.castHoldMs"))
            MacroAccessibility.setHold(false, cx, cy)
            delay(ms("g.settleMs"))

            onStatus("Waiting for bite / shaking")
            val t0 = SystemClock.uptimeMillis()
            var engaged = false
            var lastShake = 0L
            while (isActive && SystemClock.uptimeMillis() - t0 < ms("g.biteTimeoutMs")) {
                if (mode.active()) { engaged = true; break }
                val now = SystemClock.uptimeMillis()
                if (now - lastShake >= ms("s.delayMs")) {
                    Detect.pickBlob("s", "shake")?.let {
                        MacroAccessibility.tap(listOf(Pair(Screen.rx(it.cx), Screen.ry(it.cy))), 30)
                        lastShake = now
                    }
                }
                delay(15)
            }
            if (!engaged) {
                onStatus("Timeout, resetting")
                MacroAccessibility.tap(listOf(Pair(cx, cy)), 40)
                delay(1500); continue
            }

            onStatus("Reeling")
            var lastSeen = SystemClock.uptimeMillis()
            var lastFrame = -1L
            while (isActive) {
                val now = SystemClock.uptimeMillis()
                if (now - lastSeen > ms("g.endGraceMs")) break
                val f = Screen.frameId
                if (f == lastFrame) { delay(2); continue }
                lastFrame = f
                if (mode.step()) lastSeen = now
                delay(1)
            }
            mode.stop()
            caught++
            onStatus("Done #$caught")
            delay(ms("g.postCatchMs"))
        }
    }
}