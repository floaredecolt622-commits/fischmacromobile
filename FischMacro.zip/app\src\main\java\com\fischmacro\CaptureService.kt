package com.fischmacro

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import kotlinx.coroutines.*

class CaptureService : Service() {
    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        @Volatile var running = false
    }

    private var projection: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var overlay: Overlay? = null
    private var bot: Bot? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Config.init(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("fm", "Fisch Macro", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "fm")
            .setContentTitle("Fisch Macro active")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>(EXTRA_DATA)
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        thread = HandlerThread("capture").also { it.start() }
        val bgHandler = Handler(thread!!.looper)
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { main.post { stopSelf() } }
        }, bgHandler)

        val dm = DisplayMetrics()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).getDisplay(0).getRealMetrics(dm)
        val rw = maxOf(dm.widthPixels, dm.heightPixels)
        val rh = minOf(dm.widthPixels, dm.heightPixels)
        Screen.realW = rw; Screen.realH = rh
        val cw = (rw / 2) and 1.inv()
        val ch = (rh / 2) and 1.inv()

        reader = ImageReader.newInstance(cw, ch, PixelFormat.RGBA_8888, 2).also { r ->
            r.setOnImageAvailableListener({ ir ->
                val img = try { ir.acquireLatestImage() } catch (e: Exception) { null }
                if (img != null) try { Screen.update(img) } finally { img.close() }
            }, bgHandler)
        }
        vd = proj.createVirtualDisplay("fischcap", cw, ch, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, bgHandler)

        bot = Bot(scope) { s -> main.post { overlay?.setStatus(s) } }
        overlay = Overlay(this, bot!!) { stopSelf() }.also { it.show() }
        running = true
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        running = false
        bot?.stop(); scope.cancel()
        overlay?.hide()
        vd?.release(); reader?.close()
        projection?.stop(); thread?.quitSafely()
        super.onDestroy()
    }
}