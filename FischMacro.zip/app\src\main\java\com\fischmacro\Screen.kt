package com.fischmacro

import android.graphics.Bitmap
import android.media.Image

object Screen {
    @Volatile var w = 0
    @Volatile var h = 0
    @Volatile var realW = 1
    @Volatile var realH = 1
    @Volatile var frameId = 0L
    private var bmp: Bitmap? = null
    private val lock = Any()

    class Region(val px: IntArray, val w: Int, val h: Int, val x0: Int, val y0: Int)

    fun update(img: Image) {
        val pl = img.planes[0]
        val bw = pl.rowStride / pl.pixelStride
        synchronized(lock) {
            var b = bmp
            if (b == null || b.width != bw || b.height != img.height) {
                b = Bitmap.createBitmap(bw, img.height, Bitmap.Config.ARGB_8888)
                bmp = b
            }
            pl.buffer.rewind()
            b!!.copyPixelsFromBuffer(pl.buffer)
        }
        w = img.width; h = img.height
        frameId++
    }

    fun grab(r: FloatArray): Region? = synchronized(lock) {
        val b = bmp ?: return null
        val fw = w; val fh = h
        if (fw <= 0 || fh <= 0) return null
        val x0 = (r[0] * fw).toInt().coerceIn(0, fw - 2)
        val y0 = (r[1] * fh).toInt().coerceIn(0, fh - 2)
        val x1 = (r[2] * fw).toInt().coerceIn(x0 + 1, fw)
        val y1 = (r[3] * fh).toInt().coerceIn(y0 + 1, fh)
        val rw = x1 - x0; val rh = y1 - y0
        val px = IntArray(rw * rh)
        b.getPixels(px, 0, rw, x0, y0, rw, rh)
        Region(px, rw, rh, x0, y0)
    }

    fun pixelAtReal(x: Float, y: Float): Int? = synchronized(lock) {
        val b = bmp ?: return null
        b.getPixel((x * w / realW).toInt().coerceIn(0, w - 1), (y * h / realH).toInt().coerceIn(0, h - 1))
    }

    fun rx(frameX: Float) = frameX * realW / w
    fun ry(frameY: Float) = frameY * realH / h
}