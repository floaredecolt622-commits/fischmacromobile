package com.fischmacro

import android.content.Context
import android.graphics.*
import android.os.Build
import android.view.*
import android.widget.*

class Overlay(private val ctx: Context, private val bot: Bot, private val onClose: () -> Unit) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val pickKeys = listOf("bar", "fish", "shake", "note", "rhui", "target")
    private var pickIdx = 0
    private lateinit var panel: LinearLayout
    private lateinit var status: TextView
    private lateinit var startBtn: Button
    private lateinit var modeBtn: Button
    private lateinit var pickBtn: Button
    private var debug: View? = null
    private val panelLp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 0 }

    private fun fullLp(touchable: Boolean) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            (if (touchable) 0 else WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE),
        PixelFormat.TRANSLUCENT).apply {
        if (Build.VERSION.SDK_INT >= 28)
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
    }

    private fun btn(t: String, click: () -> Unit) = Button(ctx).apply {
        text = t; textSize = 11f; isAllCaps = false
        setTextColor(0xFFBBBBBB.toInt()); setBackgroundColor(0xDD202020.toInt())
        setPadding(16, 4, 16, 4); minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
        setOnClickListener { click() }
    }

    fun show() {
        panel = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(0xDD101010.toInt()) }
        status = TextView(ctx).apply {
            text = "Ready"; setTextColor(0xFFBBBBBB.toInt()); textSize = 11f; setPadding(16, 4, 16, 4)
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
            setOnTouchListener { _, e ->
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = panelLp.x; oy = panelLp.y }
                    MotionEvent.ACTION_MOVE -> {
                        panelLp.x = ox + (e.rawX - sx).toInt(); panelLp.y = oy + (e.rawY - sy).toInt()
                        wm.updateViewLayout(panel, panelLp)
                    }
                }
                true
            }
        }
        startBtn = btn("Start") { toggle() }
        modeBtn = btn(Modes.names[Config.mode]) {
            Config.mode = (Config.mode + 1) % Modes.names.size
            modeBtn.text = Modes.names[Config.mode]
            if (debug != null) { hideDebug(); showDebug() }
        }
        val dbgBtn = btn("Debug") { if (debug == null) showDebug() else hideDebug() }
        pickBtn = btn("Color:${pickKeys[0]}") {
            pickIdx = (pickIdx + 1) % pickKeys.size; pickBtn.text = "Color:${pickKeys[pickIdx]}"
        }
        val eyeBtn = btn("Pick") { startPick() }
        val closeBtn = btn("X") { onClose() }
        listOf(status, startBtn, modeBtn, dbgBtn, pickBtn, eyeBtn, closeBtn).forEach { panel.addView(it) }
        wm.addView(panel, panelLp)
    }

    fun hide() {
        hideDebug()
        try { wm.removeView(panel) } catch (_: Exception) {}
    }

    fun setStatus(s: String) {
        status.text = s
        startBtn.text = if (bot.running) "Stop" else "Start"
    }

    private fun toggle() {
        if (bot.running) { bot.stop(); return }
        if (MacroAccessibility.inst == null) { toast("Enable the accessibility service first"); return }
        hideDebug()
        bot.start(); startBtn.text = "Stop"
    }

    private fun toast(s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()

    private fun showDebug() {
        val v = object : View(ctx) {
            val p = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 3f }
            override fun onDraw(c: Canvas) {
                fun r(prefix: String, color: Int) {
                    val q = Config.rect(prefix); p.color = color
                    c.drawRect(q[0] * width, q[1] * height, q[2] * width, q[3] * height, p)
                }
                r("s", 0xFFFF00FF.toInt())
                when (Config.mode) {
                    0 -> r("std", 0xFF00FFFF.toInt())
                    1 -> {
                        r("rh", 0xFF00FF00.toInt())
                        val q = Config.rect("rh"); val n = Config.f("rh.lanes").toInt().coerceIn(1, 8)
                        for (i in 1 until n) {
                            val x = (q[0] + (q[2] - q[0]) * i / n) * width
                            c.drawLine(x, q[1] * height, x, q[3] * height, p)
                        }
                    }
                    else -> r("t", 0xFFFFFF00.toInt())
                }
                p.color = 0xFFFF8000.toInt()
                c.drawCircle(Config.f("g.castX") * width, Config.f("g.castY") * height, 14f, p)
                p.color = 0xFF8080FF.toInt()
                c.drawCircle(Config.f("g.holdX") * width, Config.f("g.holdY") * height, 14f, p)
            }
        }
        debug = v; wm.addView(v, fullLp(false))
    }

    private fun hideDebug() {
        debug?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        debug = null
    }

    private fun startPick() {
        hideDebug()
        val key = pickKeys[pickIdx]
        toast("Tap the \"$key\" color on screen")
        val v = object : View(ctx) {
            override fun onTouchEvent(e: MotionEvent): Boolean {
                if (e.action == MotionEvent.ACTION_UP) {
                    val c = Screen.pixelAtReal(e.rawX, e.rawY)
                    try { wm.removeView(this) } catch (_: Exception) {}
                    if (c != null) { Config.setCol(key, c or (0xFF shl 24)); toast("$key = #%06X".format(c and 0xFFFFFF)) }
                }
                return true
            }
        }
        wm.addView(v, fullLp(true))
    }
}