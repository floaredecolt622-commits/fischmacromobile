package com.fischmacro

import android.os.SystemClock

interface ReelMode {
    fun active(): Boolean
    fun step(): Boolean
    fun stop() {}
}

object Modes {
    val names = listOf("Standard rod", "Rhythm rod", "Target-tap rod")
    fun create(i: Int): ReelMode = when (i) { 1 -> RhythmMode(); 2 -> TargetMode(); else -> StandardMode() }
}

/** Bar-follows-fish minigame: hold = bar goes one way, release = other way. PD controller. */
class StandardMode : ReelMode {
    private var lastCenter = -1f
    private var lastT = 0L
    private var vel = 0f
    private var holding = false
    private var goRight = false

    private fun setHold(want: Boolean) {
        if (want == holding) return
        holding = want
        MacroAccessibility.setHold(want, Config.f("g.holdX") * Screen.realW, Config.f("g.holdY") * Screen.realH)
    }

    override fun active(): Boolean {
        val r = Screen.grab(Config.rect("std")) ?: return false
        return Detect.count(r, Config.col("bar"), Config.f("std.tol").toInt()) >= Config.f("std.minCount")
    }

    override fun step(): Boolean {
        val reg = Screen.grab(Config.rect("std")) ?: return false
        val barC = Config.col("bar"); val fishC = Config.col("fish")
        val tol = Config.f("std.tol").toInt()
        val barCols = IntArray(reg.w); val fishCols = IntArray(reg.w)
        var total = 0
        for (y in 0 until reg.h) {
            val o = y * reg.w
            for (x in 0 until reg.w) {
                val p = reg.px[o + x]
                if (Detect.close(p, barC, tol)) { barCols[x]++; total++ }
                else if (Detect.close(p, fishC, tol)) fishCols[x]++
            }
        }
        if (total < Config.f("std.minCount")) { setHold(false); lastCenter = -1f; return false }

        val thr = maxOf(1, (reg.h * 0.5f).toInt())
        var bestL = -1; var bestR = -1; var curL = -1; var lastOn = -1; var gap = 0
        for (x in 0 until reg.w) {
            if (barCols[x] >= thr) { if (curL < 0) curL = x; lastOn = x; gap = 0 }
            else if (curL >= 0) {
                gap++
                if (gap > 3) { if (lastOn - curL > bestR - bestL) { bestL = curL; bestR = lastOn }; curL = -1 }
            }
        }
        if (curL >= 0 && lastOn - curL > bestR - bestL) { bestL = curL; bestR = lastOn }
        if (bestL < 0) return true

        var fs = 0f; var fc = 0
        for (x in 0 until reg.w) if (fishCols[x] >= 2) { fs += x * fishCols[x]; fc += fishCols[x] }
        if (fc < 3) return true
        val fishX = fs / fc

        val now = SystemClock.uptimeMillis()
        val center = (bestL + bestR) / 2f
        if (lastCenter >= 0) {
            val dt = (now - lastT).coerceAtLeast(1)
            vel = vel * 0.6f + ((center - lastCenter) * 1000f / dt) * 0.4f
        }
        lastCenter = center; lastT = now

        val width = (bestR - bestL).coerceAtLeast(10)
        val u = (fishX - center) - Config.f("std.kd") * vel
        val db = Config.f("std.db") * width
        if (u > db) goRight = true else if (u < -db) goRight = false
        setHold(goRight xor (Config.f("std.invert") > 0.5f))
        return true
    }

    override fun stop() { setHold(false) }
}

/** Notes fall into lanes; tap a lane when a note-colored pixel cluster appears in the hit strip. */
class RhythmMode : ReelMode {
    private val prev = BooleanArray(16)
    private val last = LongArray(16)

    override fun active(): Boolean {
        val r = Screen.grab(Config.rect("rh")) ?: return false
        return Detect.count(r, Config.col("rhui"), Config.f("rh.tol").toInt()) >= Config.f("rh.uiMin")
    }

    override fun step(): Boolean {
        val reg = Screen.grab(Config.rect("rh")) ?: return false
        val tol = Config.f("rh.tol").toInt()
        if (Detect.count(reg, Config.col("rhui"), tol) < Config.f("rh.uiMin")) return false
        val lanes = Config.f("rh.lanes").toInt().coerceIn(1, 8)
        val laneW = reg.w / lanes
        val note = Config.col("note"); val minPx = Config.f("rh.minPx").toInt()
        val cd = Config.f("rh.cooldownMs").toLong()
        val now = SystemClock.uptimeMillis()
        val taps = ArrayList<Pair<Float, Float>>()
        for (l in 0 until lanes) {
            var n = 0
            for (y in 0 until reg.h) {
                val o = y * reg.w
                for (x in l * laneW until (l + 1) * laneW) if (Detect.close(reg.px[o + x], note, tol)) n++
            }
            val present = n >= minPx
            if (present && !prev[l] && now - last[l] >= cd) {
                taps += Pair(Screen.rx(reg.x0 + (l + 0.5f) * laneW), Screen.ry(reg.y0 + reg.h / 2f))
                last[l] = now
            }
            prev[l] = present
        }
        if (taps.isNotEmpty()) MacroAccessibility.tap(taps, 30)
        return true
    }
}

/** Taps blobs of a color as they show up (moving targets, click-the-orb style). */
class TargetMode : ReelMode {
    private var last = 0L
    override fun active() = Detect.pickBlob("t", "target") != null
    override fun step(): Boolean {
        val b = Detect.pickBlob("t", "target") ?: return false
        val now = SystemClock.uptimeMillis()
        if (now - last >= Config.f("t.cooldownMs")) {
            MacroAccessibility.tap(listOf(Pair(Screen.rx(b.cx), Screen.ry(b.cy))), 30)
            last = now
        }
        return true
    }
}